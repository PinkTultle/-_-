const express = require('express');
const path = require('path');
const app = express();
const SerialPort = require('serialport').SerialPort;
const { ReadlineParser } = require('@serialport/parser-readline')
app.use(express.static(path.join(__dirname, '/public')));
app.use(express.static("views"));
const fs = require('fs');
const url = require('url');

//ejs 설정
app.set('views', path.join(__dirname, '/views'));
app.set('view engine', 'ejs');
app.engine("html", require("ejs").renderFile);

app.get('/', function (req, res) {
    res.render('list.ejs');
});

app.get('/:roomNumber', function (req, res) {
    const roomNumber = req.params.roomNumber;
    fs.readFile('patient_info.json', 'utf8', (err, data) => {
      if (err) {
        console.error('파일 읽기 오류:', err);
        return res.status(500).send('파일 읽기 오류');
      }
  
      // JSON 데이터를 JavaScript 객체로 파싱
      const patientData = JSON.parse(data);
  
     
      // 환자 호실에 따른 환자 정보 필터링
      const filteredPatients = patientData.filter(patient => patient["patientRoom"] === Number(roomNumber));
      // EJS 템플릿에 데이터 전달
      res.render('monitoring.ejs', { patients: filteredPatients, roomNumber: roomNumber });
    });
  });

//아두이노 설정
const serialPort = new SerialPort({path:"COM11",baudRate:9600 });
const parser = serialPort.pipe(new ReadlineParser({ delimiter: '\r\n' }));

app.get('/test/sse', (req, res) => {
    // SSE 헤더 설정
    res.setHeader('Content-Type', 'text/event-stream');
    res.setHeader('Cache-Control', 'no-cache');
    res.setHeader('Connection', 'keep-alive');
    
    // 클라이언트 연결 유지 및 데이터 보내기
    const sendSSE = (data) => {
        
       
        res.write(`data: ${JSON.stringify(data)}\n\n`);

    };
  
    // 클라이언트 연결 종료 처리
    req.on('close', () => {
      // 연결 종료 시 필요한 클리어업 작업을 수행합니다.
      
    });
  
    // 시리얼 데이터 수신 처리
    let receivedData = '';

    serialPort.open(function(){

        console.log('connected..');
        
        serialPort.on('data', function(data) {
          console.log("port on");
          
            const newdata = data.toString('utf8');
            receivedData += newdata;
            if (newdata.endsWith("\n")) { // 원하는 종료 문자열이 나타나면 처리
              console.log(receivedData);
              const cleanedString = receivedData.replace("\n", "");
              const jsonData = {
                  data: cleanedString,
              };
              sendSSE(jsonData);
              receivedData = ''; // 변수 초기화
            }
            
          });
    })

    
   
  });

  app.get('/send_room_info/:roomnumber', (req, res) => {
    const roomNumber = req.params.roomnumber;
    fs.readFile('patient_info.json', 'utf8', (err, data) => {
        if (err) {
            console.error('파일 읽기 오류:', err);
            return res.status(500).send('파일 읽기 오류');
        }

        // JSON 데이터를 JavaScript 객체로 파싱
        const patientData = JSON.parse(data);

        // 환자 호실에 따른 환자 정보 필터링
        const filteredPatients = patientData.filter(patient => patient["patientRoom"] === Number(roomNumber));

        // "load" 명령을 각각 실행
        filteredPatients.forEach((patient, i) => {
            setTimeout(() => {
                sendLoadCommand(i, patient);

                // 마지막 "load" 명령을 보낸 후에 3초 후에 "delivery" 명령 실행
                if (i === filteredPatients.length - 1) {
                    setTimeout(() => {
                        sendDeliveryCommand();
                    }, (i + 1) * 5000); // 마지막 "load" 명령 이후 3초 딜레이

                    setTimeout(() => {
                      sendDeliveryCommand2();
                  }, (i + 1) * 10000); // 마지막 "load" 명령 이후 3초 딜레이


                    setTimeout(() => {
                      sendStandCommand();
                  }, (i + 1) * 15000); // 마지막 "load" 명령 이후 3초 딜레이

                  setTimeout(() => {
                    sendStandCommand3();
                }, (i + 1) * 20000); // 마지막 "load" 명령 이후 3초 딜레이

                setTimeout(() => {
                  sendStandCommand4();
              }, (i + 1) * 25000); // 마지막 "load" 명령 이후 3초 딜레이

                }
            }, i * 5000); // i초 간격으로 전송 (5초 간격)
        });

        const responseData = { count: filteredPatients.length };
        res.json(responseData);
    });

    const sendLoadCommand = (i, patient) => {
        // const currentTimeInSeconds = Math.floor(Date.now() / 1000);
        // const unsignedLongIntValue = BigInt(currentTimeInSeconds);

        serialPort.write(`load:${i + 1}:${patient.patientNumber}:`, () => {
            console.log(`load:${i + 1}:${patient.patientNumber}:`);
        });
    };

    const sendDeliveryCommand = () => {
        // const currentTimeInSeconds = Math.floor(Date.now() / 1000);
        serialPort.write(`delivery::P129:`, () => {
            console.log(`delivery::P129:`);
        });
    };

    const sendDeliveryCommand2 = () => {
      // const currentTimeInSeconds = Math.floor(Date.now() / 1000);
      serialPort.write(`delivery::P130:`, () => {
          console.log(`delivery::P130:`);
      });
  };

    const sendStandCommand = () => {
      // const currentTimeInSeconds = Math.floor(Date.now() / 1000);
      serialPort.write(`stand:`, () => {
          console.log(`stand:`);
      });
  };

  const sendStandCommand3 = () => {
    // const currentTimeInSeconds = Math.floor(Date.now() / 1000);
    serialPort.write(`sleep:`, () => {
        console.log(`sleep:`);
    });
};

  const sendStandCommand4 = () => {
    // const currentTimeInSeconds = Math.floor(Date.now() / 1000);
    serialPort.write(`%`, () => {
        console.log(`%`);
    });
  };
});


app.listen(4000, () => {
    console.log('Server running 4000');
});